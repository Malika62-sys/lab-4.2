package l4;

import java.util.Scanner;

public class Workshop extends Plant{
    static int i = 0;
    private int M = 0;
    private String[] Workshop = new String[20];
    Scanner scan=new Scanner(System.in);
    public Workshop()
    {
        this.Create();
    }

    @Override
    public void Create(){
        if(i < 15)
        {
            System.out.println("Введите номер цеха");
            Workshop[M]=scan.nextLine();
            i++;
            M++;
        }
    }
    
    @Override
    public void Info()
    {
        if (M > 0)
        {
            for(int j = 0;j < M;j++)
            {
                System.out.println("Цех номер - " + Workshop[j]);
            }
        }
    }
}

