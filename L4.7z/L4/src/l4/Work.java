package l4;
import java.util.ArrayList;
import java.util.Scanner;

class Work {
    private int i = 0;
    public ArrayList<Detail> d = new ArrayList<Detail>();
    public ArrayList<Machine> m = new ArrayList<Machine>();
    public ArrayList<Workshop> w = new ArrayList<Workshop>();
    public ArrayList<Product> p = new ArrayList<Product>();
    private Scanner scan = new Scanner(System.in);
    
    public void add(int clas)
    {
        if(clas == 1)
        {
            d.add(new Detail());
        }
        if(clas == 2)
        {
            m.add(new Machine());
        }
        if(clas == 3)
        {
            w.add(new Workshop());
        }
        if(clas == 4)
        {
            p.add(new Product());
        }
    }
    
    public void clear(int clas)
    {
        if(clas == 1)
        {
            d.clear();
            System.out.println("Готово!");
        }
        if(clas == 2)
        {
            m.clear();
            System.out.println("Готово!");
        }
        if(clas == 3)
        {
            w.clear();
            System.out.println("Готово!");
        }
        if(clas == 4)
        {
            p.clear();
            System.out.println("Готово!");
        }
    }
    
    public void info(int clas)
    {
        if(clas == 1)
        {
            int t = Detail.i;
            System.out.println("Количество деталей :" + t);
            System.out.println("Детали");
            for (Detail De : d)
            {
                De.Info();
            }
        }
        if(clas == 2)
        {
            int c = Machine.i;
            System.out.println("Количество устройств :" + c);
            System.out.println("Устройства");
            for (Machine Ma : m)
            {
                Ma.Info();
            }
        }
        if(clas == 3)
        {
            int o = Workshop.i;
            System.out.println("Количество цехов :" + o);
            System.out.println("Цеха");
            for (Workshop Wo : w)
            {
                Wo.Info();
            }
        }
        if(clas == 4)
        {
            int r = Product.i;
            System.out.println("Количество изделий :" + r);
            System.out.println("Изделия");
            for (Product Pr : p)
            {
                Pr.Info();
            }
        }
    }
}