package l4;

import java.util.Scanner;
public class Machine extends Plant{
    static int i = 0;
    private int M = 0;
    
    private String[] Machine = new String[20];
    Scanner scan=new Scanner(System.in);
    
    public Machine()
    {
        this.Create();
    }
    
    @Override
    public void Create(){
        if(i < 15)
        {
            System.out.println("Введите название устройства");
            Machine[M] = scan.nextLine();
            i++;
            M++;
        }
    }
    
    @Override
    public void Info()
    {
        if(M > 0)
        {
            for(int j = 0;j < M;j++)
            {
                System.out.println(Machine[j]);
            }
        }
    }

}
