package l4;
import java.util.Scanner;
public class Detail extends Plant {

    static int i = 0;
    private int M = 0;
    
    private String[] Detail = new String[20];
    Scanner scan=new Scanner(System.in);
    
    public Detail()
    {
        this.Create();
    }
    
    @Override
    public void Create(){
        if(i < 15)
        {
            System.out.println("Название детали");
            Detail[M]=scan.nextLine();
            i++;
            M++;
        }
        else
        {
            System.out.println("Создано максимальное кол-во деталей");
        }
    }
    
    @Override
    public void Info()
    {
        if(M > 0)
        {
            for(int j = 0;j < M;j++)
            {
                System.out.println(Detail[j]);
            }
        }
    }
}
