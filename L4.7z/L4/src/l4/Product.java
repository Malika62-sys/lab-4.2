package l4;

import java.util.Scanner;
public class Product extends Plant{
    
    static int i = 0;
    private int M = 0;
    private String[] Product = new String[20];
    Scanner scan=new Scanner(System.in);
    public Product()
    {
        this.Create();
    }

    @Override
    public void Create(){
        if (i < 15)
        {
            System.out.println("Введите название изделия");
            Product[M]=scan.nextLine();
            M++;
            i++;
        }
        else
        {
            System.out.println("Создано максимальное количечство изделий");
        }
    }
    
    @Override
    public void Info()
    {
        if(M > 0)
        {
            for (int j = 0;j < M;j++)
            {
                System.out.println(Product[j]);
            }
        }
    }
}
