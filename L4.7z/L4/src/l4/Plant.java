package l4;

public abstract class Plant{
       
    public void Create()
    {
        
    }
    
    public void Info()
    {
        
    }
}
