package l4;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Work w = new Work();
        int i = 0;
        Scanner scan = new Scanner(System.in);
        
        while (i != 13) 
        {
            try 
            {
                System.out.println();
                System.out.println("----------МЕНЮ----------");
                System.out.println("Выберите действие");
                System.out.println("1 - Создать деталь");
                System.out.println("2 - Показать все детали");
                System.out.println("3 - Выкинуть все детали");
                System.out.println("4 - Купить устройство");
                System.out.println("5 - Показать все устройства");
                System.out.println("6 - Сломать все устройства");
                System.out.println("7 - Построить цех");
                System.out.println("8 - Показать все цеха");
                System.out.println("9 - Снести все цеха");
                System.out.println("10 - Добавить изделие");
                System.out.println("11 - Показать все изделия");
                System.out.println("12 - Удалить все изделия");
                System.out.println("13 - Выход из программы");
                System.out.println();
                i = scan.nextInt();
                
                switch (i) 
                {                       
                    case 1:
                        w.add(1);
                        break;
                        
                    case 2:
                        w.info(1);
                        break;
                        
                    case 3:
                        w.clear(1);
                        break;
                        
                    case 4:
                        w.add(2);
                        break;
                        
                    case 5:
                        w.info(2);
                        break;
                        
                    case 6:
                        w.clear(2);
                        break;
                        
                    case 7:
                        w.add(3);
                        break;
                        
                    case 8:
                        w.info(3);
                        break;
                        
                    case 9:
                        w.clear(3);
                        break;
                        
                    case 10:
                        w.add(4);
                        break;
                            
                    case 11:
                        w.info(4);
                        break;
                        
                    case 12:
                        w.clear(4);
                        break;
                        
                    case 13:
                        System.out.println("Программа завершена");
                        break;
                             
                    default:
                        System.out.println("Данного пункта не существует!!!");
                        break;
                        
                }
            } 
            catch (Exception ex) 
            {
                System.out.println("Данного пунка не существует!!!");
                scan.next();
            }
        }
    }
}
